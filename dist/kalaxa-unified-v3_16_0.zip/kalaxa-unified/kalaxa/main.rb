# encoding: utf-8
# Kalaxa::Main — بوت پلاگین یکپارچه.
# هسته (دامنه/ذخیره‌سازی/i18n/پل — میراث کابینت‌یار) + لایه آنالیز (میراث کالاکسا آنالیز)
require 'sketchup.rb'
require_relative 'version'
require_relative 'app/paths'
require_relative 'app/logging'
require_relative 'app/errors'
require_relative 'app/settings'
require_relative 'i18n/i18n'
require_relative 'domain/entities'
require_relative 'domain/document'
require_relative 'persistence/serializer'
require_relative 'adapter/store'
require_relative 'adapter/sync_port'
require_relative 'ui/dialog'
require_relative 'analysis_panel'

module Kalaxa
  module Main
    module_function

    def boot
      return if @booted

      App::Log.level = :debug if File.exist?(File.join(__dir__, 'DEV_BUILD'))
      App::Log.info('Kalaxa booted', version: Kalaxa::VERSION,
                                     sketchup: (defined?(Sketchup) ? Sketchup.version : 'n/a'))
      register_menu if defined?(::UI) && ::UI.respond_to?(:menu)
      @booted = true
    end

    def register_menu
      menu = ::UI.menu('Extensions').add_submenu('Kalaxa | کالاکسا')
      menu.add_item('آنالیز برش و بهینه‌سازی ورق') { Kalaxa::AnalysisPanel.show_dialog }
      menu.add_item('خروجی kitchen_snapshot.json') do
        begin
          path = Kalaxa::ProjectScanner.export_snapshot
          ::UI.messagebox("snapshot ذخیره شد:\n#{path}")
        rescue => e
          App::Log.error('snapshot export failed', message: e.message)
          ::UI.messagebox("خطا: #{e.message}")
        end
      end
      menu.add_separator
      menu.add_item('پنل پایه (تست پل و زبان)') { Kalaxa::UI::Dialog.show }
      menu.add_item('About') do
        ::UI.messagebox("Kalaxa v#{Kalaxa::VERSION}\nSketchUp #{Kalaxa::TARGET_SKETCHUP.join(' / ')}")
      end
    end
  end
end

Kalaxa::Main.boot
