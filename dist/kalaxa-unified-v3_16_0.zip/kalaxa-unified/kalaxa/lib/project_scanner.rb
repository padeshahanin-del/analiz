# encoding: utf-8
#
# KalaxaCabinet::ProjectScanner — v1.0.0
#
# مرز رسمی بین دنیای SketchUp و دنیای آنالیز.
# کل مدل را اسکن می‌کند، همه گروه‌های دارای dictionary «kalaxa_cabinet» را
# پیدا می‌کند، موقعیت و چرخش جهانی را از transformation استخراج می‌کند و
# kitchen_snapshot.json (schema_version: 1) تولید می‌کند.
#
# قواعد قطعی:
#   - همه ابعاد در snapshot به میلی‌متر (عدد صحیح) — تبدیل cm→mm فقط همین‌جا
#   - parts_flat جدا از ساختار تودرتوی cabinets
#   - count باز نمی‌شود (بازکردنش کار موتور nesting است)
#   - هیچ مصرف‌کننده‌ای مدل را مستقیم نمی‌خواند؛ فقط این JSON را می‌بیند
#
require 'json'
require 'securerandom'

module Kalaxa
  module ProjectScanner

    DICT_NAME      = 'kalaxa_cabinet'.freeze
    SCHEMA_VERSION = 2
    PLUGIN_VERSION = '1.2.0'.freeze

    # ابعاد ورق‌های پیش‌فرض؛ در نسخه بعد از project settings خوانده می‌شود
    DEFAULT_SHEETS = [
      { 'sheet_id' => 'mdf_white_16', 'material' => 'mdf', 'color_code' => 'W101',
        'thickness_mm' => 16, 'width_mm' => 3660, 'height_mm' => 1830,
        'has_grain' => false, 'price_per_sheet' => 0, 'trim_margin_mm' => 10 },
      { 'sheet_id' => 'mdf_white_8', 'material' => 'mdf', 'color_code' => 'W101',
        'thickness_mm' => 8, 'width_mm' => 3660, 'height_mm' => 1830,
        'has_grain' => false, 'price_per_sheet' => 0, 'trim_margin_mm' => 10 },
      { 'sheet_id' => 'mdf_door_16', 'material' => 'mdf_hg', 'color_code' => 'DOOR',
        'thickness_mm' => 16, 'width_mm' => 2800, 'height_mm' => 2100,
        'has_grain' => true, 'price_per_sheet' => 0, 'trim_margin_mm' => 10 },
      { 'sheet_id' => 'hdf_3', 'material' => 'hdf', 'color_code' => 'RAW',
        'thickness_mm' => 3, 'width_mm' => 2440, 'height_mm' => 1220,
        'has_grain' => false, 'price_per_sheet' => 0, 'trim_margin_mm' => 5 }
    ].freeze

    DEFAULT_CUTTING = {
      'kerf_mm' => 4,
      'allow_rotation_default' => true,
      'min_offcut_mm' => 100
    }.freeze

    module_function

    # نقطه ورود اصلی. مدل فعال را اسکن و snapshot را به‌صورت Hash برمی‌گرداند.
    # خطاها را raise نمی‌کند؛ در کلید 'scan_errors' گزارش می‌دهد تا UI نمایش دهد.
    def build_snapshot(model = Sketchup.active_model)
      t_start        = Time.now
      cabinets       = []
      parts_flat     = []
      scan_errors    = []
      scan_warnings  = []
      hidden_skipped = 0

      walk_entities(model.entities, Geom::Transformation.new) do |group, world_tr|
        next if group.deleted?
        if group.respond_to?(:hidden?) && group.hidden?
          hidden_skipped += 1 if group.attribute_dictionary(DICT_NAME)
          next
        end
        dict = group.attribute_dictionary(DICT_NAME)
        next unless dict

        begin
          cab = extract_cabinet(group, dict, world_tr)
          cabinets << cab
          parts_flat.concat(extract_parts(group, dict, cab['kalaxa_id'], scan_errors))
        rescue => e
          scan_errors << "خطا در خواندن کابینت «#{safe_name(group)}»: #{e.message}"
        end
      end

      scan_warnings << "#{hidden_skipped} کابینت مخفی از اسکن حذف شد" if hidden_skipped > 0
      settings = read_project_settings(model)

      snapshot = {
        'schema_version' => SCHEMA_VERSION,
        'snapshot_id'    => SecureRandom.uuid,
        'created_at'     => Time.now.strftime('%Y-%m-%dT%H:%M:%S%:z'),
        'source' => {
          'plugin_version'   => PLUGIN_VERSION,
          'sketchup_version' => Sketchup.version,
          'model_name'       => (model.path.empty? ? 'untitled.skp' : File.basename(model.path))
        },
        'project_settings_snapshot' => settings,
        'sheets'      => sheets_for(settings),
        'cutting'     => DEFAULT_CUTTING.dup,
        'stock_offcuts' => [],
        'cabinets'      => cabinets,
        'parts_flat'    => parts_flat,
        'scan_errors'   => scan_errors,
        'scan_warnings' => scan_warnings,
        'scan_stats'    => {
          'duration_ms'    => ((Time.now - t_start) * 1000).round,
          'cabinets_found' => cabinets.length,
          'parts_rows'     => parts_flat.length,
          'hidden_skipped' => hidden_skipped
        }
      }
      snapshot
    end

    # snapshot را روی دیسک می‌نویسد و مسیر را برمی‌گرداند.
    # مسیر پیش‌فرض: کنار فایل مدل؛ اگر مدل ذخیره نشده، پوشه موقت سیستم
    # (هرگز داخل پوشه Plugins نمی‌نویسیم — read-only است)
    def export_snapshot(model = Sketchup.active_model, out_path = nil)
      snapshot = build_snapshot(model)
      out_path ||= default_export_path(model)
      File.write(out_path, JSON.pretty_generate(snapshot))
      out_path
    end

    def default_export_path(model)
      base = if model.path && !model.path.empty?
               File.dirname(model.path)
             else
               ENV['TMPDIR'] || ENV['TEMP'] || Dir.tmpdir
             end
      File.join(base, 'kitchen_snapshot.json')
    end

    # -------------------------------------------------------------- internal

    # پیمایش بازگشتی با انباشت transformation — تا کابینت‌های داخل گروه‌های
    # چیدمان (مثلاً گروه «دیوار شمالی») هم مختصات جهانی درست بگیرند.
    def walk_entities(entities, parent_tr, &block)
      entities.each do |e|
        next if e.respond_to?(:deleted?) && e.deleted?
        next unless e.respond_to?(:entities) || e.is_a?(Sketchup::Group)
        if e.is_a?(Sketchup::Group)
          world_tr = parent_tr * e.transformation
          yield(e, world_tr)
          walk_entities(e.entities, world_tr, &block)
        elsif e.is_a?(Sketchup::ComponentInstance)
          world_tr = parent_tr * e.transformation
          yield(e, world_tr) if e.attribute_dictionary(DICT_NAME)
          walk_entities(e.definition.entities, world_tr, &block)
        end
      end
    end

    def extract_cabinet(group, dict, world_tr)
      params = parse_json_attr(dict, 'params') || {}
      origin = world_tr.origin

      {
        'kalaxa_id'   => (dict['kalaxa_id'] || "pid-#{group.persistent_id}").to_s,
        'template_id' => dict['template_id'].to_s,
        'category'    => dict['category'].to_s,
        'label_fa'    => (dict['label_fa'] || safe_name(group)).to_s,
        'params'      => params,
        'world_transform' => {
          # مختصات جهانی به سانتی‌متر (params هم cm است)؛ mm فقط برای ابعاد برش
          'origin_cm' => [
            to_cm(origin.x), to_cm(origin.y), to_cm(origin.z)
          ],
          'rotation_z_deg' => rotation_z_deg(world_tr)
        }
      }
    end

    def extract_parts(group, dict, cabinet_id, scan_errors)
      raw = parse_json_attr(dict, 'parts')
      unless raw.is_a?(Array)
        scan_errors << "کابینت «#{safe_name(group)}» attribute «parts» ندارد یا نامعتبر است"
        return []
      end

      uid_counters = Hash.new(0)
      raw.map do |p|
        fallback_uid = begin
          key = "#{cabinet_id}:#{p['key']}"
          uid_counters[key] += 1
          "#{key}:#{uid_counters[key]}"
        end
        {
          'part_uid'      => (p['part_uid'] || fallback_uid).to_s,
          'cabinet_id'    => cabinet_id,
          'key'           => p['key'].to_s,
          'name_fa'       => p['name_fa'].to_s,
          'count'         => p['count'].to_i.clamp(1, 999),
          # قطعات در attribute به cm ذخیره شده‌اند → تبدیل به mm صحیح
          'cut_length_mm' => cm_to_mm(p['cut_length_cm'] || p['cut_length_mm'], p.key?('cut_length_mm')),
          'cut_width_mm'  => cm_to_mm(p['cut_width_cm']  || p['cut_width_mm'],  p.key?('cut_width_mm')),
          'thickness_mm'  => p['thickness_mm'].to_i,
          'sheet_id'      => p['sheet_id'].to_s,
          'grain'         => normalize_grain(p['grain']),
          'allow_rotation'=> p.key?('allow_rotation') ? !!p['allow_rotation'] : true,
          'edge'          => p['edge'].is_a?(Hash) ? p['edge'] : {},
          'groove'        => p['groove'].is_a?(Hash) ? p['groove'] : {},
          'note'          => p['note'].to_s
        }
      end
    end

    def normalize_grain(g)
      %w[length width none].include?(g.to_s) ? g.to_s : 'none'
    end

    def cm_to_mm(value, already_mm)
      v = value.to_f
      already_mm ? v.round : (v * 10).round
    end

    def to_cm(inches_length)
      (inches_length.to_f * 2.54).round(2)
    end

    # چرخش حول محور Z از بردار x محلی
    def rotation_z_deg(tr)
      x_axis = tr.xaxis
      (Math.atan2(x_axis.y, x_axis.x) * 180.0 / Math::PI).round(1)
    end

    def parse_json_attr(dict, key)
      raw = dict[key]
      return raw unless raw.is_a?(String)
      JSON.parse(raw)
    rescue JSON::ParserError
      nil
    end

    def read_project_settings(model)
      dict = model.attribute_dictionary('kalaxa_project')
      defaults = {
        'body_thickness_mm' => 16,
        'back_thickness_mm' => 8,
        'groove_depth_mm'   => 8,
        'edge_mode'         => 'no_deduct',
        'project_height_cm' => 260
      }
      return defaults unless dict
      defaults.each_key { |k| defaults[k] = dict[k] if dict[k] }
      defaults
    end

    def sheets_for(_settings)
      # نسخه ۱: پیش‌فرض‌ها؛ نسخه بعد از پنل تنظیمات پروژه خوانده می‌شود
      DEFAULT_SHEETS.map(&:dup)
    end

    def safe_name(group)
      n = group.respond_to?(:name) ? group.name : ''
      n.to_s.empty? ? '(بدون نام)' : n
    end

  end
end
