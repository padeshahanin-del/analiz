/**
 * kalaxa-settings.js — v1.12.0
 * منطق تنظیمات پروژه (State 5 قرارداد): پیش‌فرض‌ها، اعتبارسنجی، اعمال روی snapshot.
 * ماندگاری سمت Ruby است (AttributeDictionary مدل)؛ این ماژول فقط منطق خالص است.
 * JS خالص، UMD، بدون وابستگی.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.KalaxaSettings = factory();
  }
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var VERSION = '1.12.0';

  // نوع ریل کشو — کلید پایدار (برای قیمت/گزارش) + برچسب فارسی
  var SLIDE_TYPES = {
    ball_3piece: 'ساچمه‌ای سه‌تکه',
    tandem: 'تاندم (زیرکشویی)',
    roller: 'غلتکی ساده'
  };

  // ضخامت‌های استاندارد نوار لبه (میلی‌متر)
  var EDGE_BAND_THICKNESS = [1, 2];

  // نگاشت نقش قطعه از روی key قرارداد snapshot — مبنای «ورق بدنه/درب/پشت‌بند»
  var ROLE_KEYS = {
    body: ['side', 'top_bottom', 'bottom', 'shelf', 'rail_top', 'drawer_side', 'drawer_back'],
    door: ['door', 'drawer_front'],
    back: ['back'],
    drawer_bottom: ['drawer_bottom']
  };

  // تب‌های شناخته‌شدهٔ پنل — مبنای اعتبارسنجی چیدمان تب‌ها ('settings' مخفی‌شدنی نیست)
  var PANEL_TABS = ['cut', 'install', 'cabinets', 'placement', 'material',
                    'hardware', 'price', 'templates', 'scenarios', 'settings', 'rules'];

  // انواع علامت قابل‌تعریف کاربر — کد/حرف کنار هر ضلع در نقشه برش و لیست قطعات
  // (نه رنگ، نه خط — کدهایی که کارگر می‌شناسد. کاربر خودش تعیین می‌کند تا با چیزی
  // که در فرمول‌ها/برچسب‌گذاری دیگر استفاده نشده تداخل نداشته باشد.)
  // miter = فارسی‌بر: کج‌بری دقیقاً ۴۵° در گوشه (اتصال قاب/کابینت).
  // bevel = کج‌بری/زاویه: برش با زاویهٔ دلخواه (غیر از فارسی)؛ دو نوع کار جداییم، کد جدا.
  var MARK_KEYS = ['band_body', 'band_door', 'groove', 'miter', 'bevel'];
  var MARK_LABELS_FA = {
    band_body: 'نوار بدنه', band_door: 'نوار درب', groove: 'شیار',
    miter: 'فارسی‌بر (۴۵°)', bevel: 'کج‌بری با زاویه'
  };
  var DEFAULT_MARKS = {
    band_body: { code: '#', label_fa: MARK_LABELS_FA.band_body },
    band_door: { code: 'P', label_fa: MARK_LABELS_FA.band_door },
    groove:    { code: 'W', label_fa: MARK_LABELS_FA.groove },
    miter:     { code: 'F', label_fa: MARK_LABELS_FA.miter },
    bevel:     { code: 'Z', label_fa: MARK_LABELS_FA.bevel }
  };

  var DEFAULTS = {
    settings_version: 1,
    // واحد نمایش 'cm' پیش‌فرض | 'mm' (داده‌ها داخلی mm)؛ tab_order/hidden_tabs چیدمان تب‌ها
    display: { unit: 'cm', tab_order: PANEL_TABS.slice(), hidden_tabs: [] },
    project: {
      body_sheet_id: 'mdf_white_16',         // ورق بدنه (ضخامت بدنه = ضخامت همین ورق)
      door_sheet_id: 'mdf_door_16',          // ورق درب (ضخامت درب = ضخامت همین ورق)
      back_sheet_id: 'mdf_white_8',          // ورق پشت‌بند کابینت (قرارداد دامنه: MDF ۸)
      drawer_bottom_sheet_id: 'hdf_3',       // ورق کف کشو
      slide_type: 'ball_3piece',
      // نوار لبه: ضخامت (۱/۲ میل) + توضیحات آزاد؛ بدنه تیک «کسر» دارد یعنی ضخامت نوار
      // از اندازهٔ برش قطعه کم می‌شود تا اندازهٔ نهایی درست دربیاید (اثر واقعی در نستینگ).
      edge_band: {
        body: { thickness_mm: 1, note: '', subtract: true },
        door: { thickness_mm: 2, note: '' }
      },
      // علامت هر نوع کار روی نقشه برش/لیست قطعات — کد را کاربر تعیین می‌کند
      marks: clone(DEFAULT_MARKS),
      // شیت قیمت کامل — یک‌بار وارد و در مدل ماندگار (assembly به‌ازای هر تمپلیت کابینت،
      // دیگر برای تمپلیت‌های قیمت‌گذاری‌شده پرسیده نمی‌شود). موتور: kalaxa-price-sheet.js
      price_sheet: {
        currency: 'تومان',
        sheets: {},            // { sheet_id: قیمت هر ورق }
        hardware: {},          // { item_id: قیمت واحد } — لولا/ریل/دستگیره/پایه/...
        edge_body_per_m: 0,
        edge_door_per_m: 0,
        assembly: {},          // { template_id_یا_دسته: قیمت مونتاژ هر یونیت }
        trim: { crown_per_m: 0, light_rail_per_m: 0, kick_per_m: 0 },
        // پروفیل درب آلومینیومی/شیشه‌ای — دو SKU جدا (ساده/دستگیره)، هر کدام شاخهٔ خودش.
        // موتور: kalaxa-door-profile.js + kalaxa-linear-nesting.js
        door_profile: { door_types: [], plain_bar_length_mm: 0, plain_price_per_bar: 0, plain_kerf_mm: 3,
                        handle_bar_length_mm: 0, handle_price_per_bar: 0, handle_kerf_mm: 3 },
        // ریل کمد دیواری — ریل عمومی برشی (ساده/لبه‌دار) + کیت مکانیزم برند (قیمت ثابت هر کمد).
        // موتور: kalaxa-wall-rail.js
        wall_rail: { plain_bar_length_mm: 0, plain_price_per_bar: 0, plain_kerf_mm: 3,
                     edged_bar_length_mm: 0, edged_price_per_bar: 0, edged_kerf_mm: 3,
                     kits: { blum: 0, fantoni: 0, meleni: 0 } }
      },
      // کاتالوگ تمپلیت کابینت — رجیستری، نه مصرف (تمپلیت حذف‌شده از اسکن جاری هم می‌ماند).
      // موتور: kalaxa-template-catalog.js. کلید = template_id.
      template_catalog: {}
    },
    sheets: [
      { sheet_id: 'mdf_white_16', material: 'mdf', color_code: 'W101', thickness_mm: 16,
        width_mm: 3660, height_mm: 1830, has_grain: false, price_per_sheet: 0, trim_margin_mm: 10 },
      { sheet_id: 'mdf_white_8', material: 'mdf', color_code: 'W101', thickness_mm: 8,
        width_mm: 3660, height_mm: 1830, has_grain: false, price_per_sheet: 0, trim_margin_mm: 10 },
      { sheet_id: 'mdf_door_16', material: 'mdf_hg', color_code: 'DOOR', thickness_mm: 16,
        width_mm: 2800, height_mm: 2100, has_grain: true, price_per_sheet: 0, trim_margin_mm: 10 },
      { sheet_id: 'hdf_3', material: 'hdf', color_code: 'RAW', thickness_mm: 3,
        width_mm: 2440, height_mm: 1220, has_grain: false, price_per_sheet: 0, trim_margin_mm: 5 }
    ],
    cutting: { kerf_mm: 4, allow_rotation_default: true, min_offcut_mm: 100 }
  };

  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function finitePos(n) { return typeof n === 'number' && isFinite(n) && n > 0; }
  function finiteNonNeg(n) { return typeof n === 'number' && isFinite(n) && n >= 0; }

  function defaults() { return clone(DEFAULTS); }

  /** اعتبارسنجی تنظیمات — خروجی { ok, errors[fa] } */
  function validate(settings) {
    var errors = [];
    if (!settings || typeof settings !== 'object' || Array.isArray(settings)) {
      return { ok: false, errors: ['تنظیمات باید شیء JSON باشد'] };
    }
    if (!Array.isArray(settings.sheets) || !settings.sheets.length) {
      errors.push('حداقل یک ورق باید تعریف شود');
    }
    var ids = {};
    (settings.sheets || []).forEach(function (s, i) {
      var tag = 'ورق #' + (i + 1) + (s && s.sheet_id ? ' (' + s.sheet_id + ')' : '');
      if (!s || typeof s !== 'object') { errors.push(tag + ' نامعتبر'); return; }
      if (!s.sheet_id || typeof s.sheet_id !== 'string' || !s.sheet_id.trim()) {
        errors.push(tag + ': sheet_id جاافتاده');
      } else if (ids[s.sheet_id]) { errors.push(tag + ': sheet_id تکراری'); }
      else ids[s.sheet_id] = true;
      if (!finitePos(s.width_mm)) errors.push(tag + ': width_mm نامعتبر');
      if (!finitePos(s.height_mm)) errors.push(tag + ': height_mm نامعتبر');
      if (!finitePos(s.thickness_mm)) errors.push(tag + ': thickness_mm نامعتبر');
      if (s.trim_margin_mm != null && !finiteNonNeg(s.trim_margin_mm)) errors.push(tag + ': trim_margin_mm نامعتبر');
      if (s.price_per_sheet != null && !finiteNonNeg(s.price_per_sheet)) errors.push(tag + ': price_per_sheet نامعتبر');
      if (s.width_mm && s.height_mm && s.trim_margin_mm != null &&
          (s.width_mm <= 2 * s.trim_margin_mm || s.height_mm <= 2 * s.trim_margin_mm)) {
        errors.push(tag + ': trim از نصف ابعاد ورق بزرگ‌تر است');
      }
    });
    var c = settings.cutting || {};
    if (c.kerf_mm != null && !finiteNonNeg(c.kerf_mm)) errors.push('kerf_mm نامعتبر');
    if (c.kerf_mm != null && c.kerf_mm > 20) errors.push('kerf_mm غیرمنطقی (>20mm)');
    if (c.min_offcut_mm != null && !finiteNonNeg(c.min_offcut_mm)) errors.push('min_offcut_mm نامعتبر');
    if (settings.display != null) {
      if (typeof settings.display !== 'object' || Array.isArray(settings.display)) {
        errors.push('display باید شیء باشد');
      } else {
        var d = settings.display;
        if (d.unit != null && d.unit !== 'cm' && d.unit !== 'mm') {
          errors.push("display.unit فقط 'cm' یا 'mm' — مقدار فعلی: " + d.unit);
        }
        ['tab_order', 'hidden_tabs'].forEach(function (k) {
          if (d[k] == null) return;
          if (!Array.isArray(d[k])) { errors.push('display.' + k + ' باید آرایه باشد'); return; }
          d[k].forEach(function (t) {
            if (PANEL_TABS.indexOf(t) === -1) errors.push('display.' + k + ': تب ناشناخته «' + t + '»');
          });
        });
        if (Array.isArray(d.hidden_tabs) && d.hidden_tabs.indexOf('settings') !== -1) {
          errors.push('تب تنظیمات مخفی‌شدنی نیست (راه برگشت بسته می‌شود)');
        }
      }
    }
    if (settings.project != null) {
      var pr = settings.project;
      if (typeof pr !== 'object' || Array.isArray(pr)) {
        errors.push('project باید شیء باشد');
      } else {
        var sheetIds = {};
        (settings.sheets || []).forEach(function (s) { if (s && s.sheet_id) sheetIds[s.sheet_id] = true; });
        ['body_sheet_id', 'door_sheet_id', 'back_sheet_id', 'drawer_bottom_sheet_id'].forEach(function (k) {
          if (pr[k] != null && !sheetIds[pr[k]]) {
            errors.push('project.' + k + ' به ورق ناموجود «' + pr[k] + '» اشاره دارد');
          }
        });
        if (pr.slide_type != null && !SLIDE_TYPES[pr.slide_type]) {
          errors.push('project.slide_type ناشناخته: ' + pr.slide_type +
            ' (مجاز: ' + Object.keys(SLIDE_TYPES).join('، ') + ')');
        }
        if (pr.edge_band != null) {
          var eb = pr.edge_band;
          if (typeof eb !== 'object' || Array.isArray(eb)) {
            errors.push('project.edge_band باید شیء باشد');
          } else {
            ['body', 'door'].forEach(function (side) {
              var b = eb[side];
              if (b == null) return;
              if (typeof b !== 'object' || Array.isArray(b)) {
                errors.push('project.edge_band.' + side + ' باید شیء باشد'); return;
              }
              if (b.thickness_mm != null && EDGE_BAND_THICKNESS.indexOf(b.thickness_mm) === -1) {
                errors.push('نوار ' + (side === 'body' ? 'بدنه' : 'درب') + ': ضخامت فقط ' +
                  EDGE_BAND_THICKNESS.join(' یا ') + ' میل — مقدار: ' + b.thickness_mm);
              }
              if (b.note != null && typeof b.note !== 'string') {
                errors.push('project.edge_band.' + side + '.note باید متن باشد');
              }
              if (side === 'body' && b.subtract != null && typeof b.subtract !== 'boolean') {
                errors.push('project.edge_band.body.subtract باید بولین باشد');
              }
            });
          }
        }
        if (pr.marks != null) {
          var mk = pr.marks;
          if (typeof mk !== 'object' || Array.isArray(mk)) {
            errors.push('project.marks باید شیء باشد');
          } else {
            var seenCodes = {};
            MARK_KEYS.forEach(function (mkey) {
              var m = mk[mkey];
              if (m == null) return;
              if (typeof m !== 'object' || Array.isArray(m)) {
                errors.push('project.marks.' + mkey + ' باید شیء باشد'); return;
              }
              var code = (m.code == null ? '' : String(m.code)).trim();
              if (!code) {
                errors.push('علامت «' + (MARK_LABELS_FA[mkey] || mkey) + '» کد ندارد');
                return;
              }
              if (code.length > 3) {
                errors.push('علامت «' + (MARK_LABELS_FA[mkey] || mkey) + '»: کد حداکثر ۳ نویسه — «' + code + '»');
              }
              var norm = code.toLowerCase();
              if (seenCodes[norm]) {
                errors.push('کد «' + code + '» تکراری است (هم برای «' + seenCodes[norm] +
                  '» و هم «' + (MARK_LABELS_FA[mkey] || mkey) + '»)');
              } else {
                seenCodes[norm] = MARK_LABELS_FA[mkey] || mkey;
              }
            });
          }
        }
        if (pr.price_sheet != null) {
          var ps = pr.price_sheet;
          if (typeof ps !== 'object' || Array.isArray(ps)) {
            errors.push('project.price_sheet باید شیء باشد');
          } else {
            if (ps.currency != null && typeof ps.currency !== 'string') {
              errors.push('project.price_sheet.currency باید متن باشد');
            }
            ['edge_body_per_m', 'edge_door_per_m'].forEach(function (k) {
              if (ps[k] != null && !finiteNonNeg(ps[k])) {
                errors.push('project.price_sheet.' + k + ' باید عدد نامنفی باشد');
              }
            });
            ['sheets', 'hardware', 'assembly'].forEach(function (k) {
              var obj = ps[k];
              if (obj == null) return;
              if (typeof obj !== 'object' || Array.isArray(obj)) {
                errors.push('project.price_sheet.' + k + ' باید شیء باشد'); return;
              }
              Object.keys(obj).forEach(function (code) {
                if (!finiteNonNeg(obj[code])) {
                  errors.push('project.price_sheet.' + k + '.' + code + ' باید عدد نامنفی باشد — مقدار: ' + obj[code]);
                }
              });
            });
            if (ps.trim != null) {
              if (typeof ps.trim !== 'object' || Array.isArray(ps.trim)) {
                errors.push('project.price_sheet.trim باید شیء باشد');
              } else {
                ['crown_per_m', 'light_rail_per_m', 'kick_per_m',
                 'crown_bar_length_mm', 'light_rail_bar_length_mm', 'kick_bar_length_mm',
                 'crown_price_per_bar', 'light_rail_price_per_bar', 'kick_price_per_bar',
                 'crown_kerf_mm', 'light_rail_kerf_mm', 'kick_kerf_mm'].forEach(function (k) {
                  if (ps.trim[k] != null && !finiteNonNeg(ps.trim[k])) {
                    errors.push('project.price_sheet.trim.' + k + ' باید عدد نامنفی باشد');
                  }
                });
              }
            }
            if (ps.door_profile != null) {
              var dpv = ps.door_profile;
              if (typeof dpv !== 'object' || Array.isArray(dpv)) {
                errors.push('project.price_sheet.door_profile باید شیء باشد');
              } else {
                if (dpv.door_types != null && !Array.isArray(dpv.door_types)) {
                  errors.push('project.price_sheet.door_profile.door_types باید آرایه باشد');
                }
                ['plain_bar_length_mm', 'plain_price_per_bar', 'plain_kerf_mm',
                 'handle_bar_length_mm', 'handle_price_per_bar', 'handle_kerf_mm'].forEach(function (k) {
                  if (dpv[k] != null && !finiteNonNeg(dpv[k])) {
                    errors.push('project.price_sheet.door_profile.' + k + ' باید عدد نامنفی باشد');
                  }
                });
              }
            }
            if (ps.wall_rail != null) {
              var wrv = ps.wall_rail;
              if (typeof wrv !== 'object' || Array.isArray(wrv)) {
                errors.push('project.price_sheet.wall_rail باید شیء باشد');
              } else {
                ['plain_bar_length_mm', 'plain_price_per_bar', 'plain_kerf_mm',
                 'edged_bar_length_mm', 'edged_price_per_bar', 'edged_kerf_mm'].forEach(function (k) {
                  if (wrv[k] != null && !finiteNonNeg(wrv[k])) {
                    errors.push('project.price_sheet.wall_rail.' + k + ' باید عدد نامنفی باشد');
                  }
                });
                if (wrv.kits != null) {
                  if (typeof wrv.kits !== 'object' || Array.isArray(wrv.kits)) {
                    errors.push('project.price_sheet.wall_rail.kits باید شیء باشد');
                  } else {
                    Object.keys(wrv.kits).forEach(function (brand) {
                      if (!finiteNonNeg(wrv.kits[brand])) {
                        errors.push('project.price_sheet.wall_rail.kits.' + brand + ' باید عدد نامنفی باشد');
                      }
                    });
                  }
                }
              }
            }
          }
        }
        if (pr.template_catalog != null) {
          if (typeof pr.template_catalog !== 'object' || Array.isArray(pr.template_catalog)) {
            errors.push('project.template_catalog باید شیء باشد');
          } else {
            Object.keys(pr.template_catalog).forEach(function (key) {
              var t = pr.template_catalog[key];
              if (t == null || typeof t !== 'object' || Array.isArray(t)) {
                errors.push('project.template_catalog.' + key + ' باید شیء باشد'); return;
              }
              if (t.label_fa != null && typeof t.label_fa !== 'string') {
                errors.push('project.template_catalog.' + key + '.label_fa باید متن باشد');
              }
            });
          }
        }
      }
    }
    return { ok: errors.length === 0, errors: errors };
  }

  function roleOfKey(key) {
    for (var role in ROLE_KEYS) {
      if (ROLE_KEYS[role].indexOf(key) !== -1) return role;
    }
    return null;
  }

  /** واحد نمایش مؤثر از تنظیمات (پیش‌فرض cm — تنظیمات قدیمیِ بدون display هم cm می‌گیرند). */
  function displayUnit(settings) {
    var u = settings && settings.display && settings.display.unit;
    return u === 'mm' ? 'mm' : 'cm';
  }

  /** mm داخلی → عدد در واحد نمایش (cm با حداکثر یک اعشار). برای فرم‌های ورودی. */
  function toUnit(mm, unit) {
    if (typeof mm !== 'number' || !isFinite(mm)) return null;
    return unit === 'mm' ? Math.round(mm) : Math.round(mm) / 10;
  }

  /** عدد واردشده در واحد نمایش → mm داخلی (صحیح). ورودی نامعتبر → null. */
  function fromUnit(val, unit) {
    var n = typeof val === 'number' ? val : parseFloat(val);
    if (!isFinite(n)) return null;
    return Math.round(unit === 'mm' ? n : n * 10);
  }

  /**
   * اعمال قطعی تنظیمات روی snapshot (کلون — ورودی mutate نمی‌شود).
   * sheets تنظیمات منبع حقیقت است و جایگزین snapshot.sheets می‌شود؛
   * cutting به‌صورت merge اعمال می‌شود.
   * @returns { snapshot, warnings[fa] }
   */
  function applyToSnapshot(snapshot, settings) {
    var s = clone(snapshot);
    var warnings = [];
    if (!settings) return { snapshot: s, warnings: warnings };

    if (Array.isArray(settings.sheets) && settings.sheets.length) {
      var newIds = {};
      settings.sheets.forEach(function (sh) { newIds[sh.sheet_id] = true; });
      // آشتی‌سنجی: قطعاتی که به ورق حذف‌شده ارجاع دارند
      var missing = {};
      (s.parts_flat || []).forEach(function (p) {
        if (!newIds[p.sheet_id]) missing[p.sheet_id] = (missing[p.sheet_id] || 0) + 1;
      });
      Object.keys(missing).forEach(function (id) {
        warnings.push(missing[id] + ' ردیف قطعه به ورق «' + id +
          '» ارجاع دارد که در تنظیمات جدید نیست — آنالیز با خطا رد خواهد شد');
      });
      s.sheets = clone(settings.sheets);
    }
    if (settings.cutting) {
      s.cutting = Object.assign({}, s.cutting || {}, clone(settings.cutting));
    }

    // تنظیمات پروژه: نگاشت نقش‌محور قطعات به ورق انتخابی (بدنه/درب/پشت‌بند).
    // ضخامت قطعه = ضخامت ورق مقصد. ابعاد پارامتریک (که به ضخامت وابسته‌اند) این‌جا
    // بازمحاسبه نمی‌شوند — آن کار دامنهٔ Ruby است و در اسکن بعدی انجام می‌شود؛
    // اگر ضخامتی عوض شود، صادقانه هشدار می‌دهیم.
    if (settings.project) {
      var pr = settings.project;
      var bySheet = {};
      (s.sheets || []).forEach(function (sh) { bySheet[sh.sheet_id] = sh; });
      var target = {
        body: bySheet[pr.body_sheet_id] || null,
        door: bySheet[pr.door_sheet_id] || null,
        back: bySheet[pr.back_sheet_id] || null,
        drawer_bottom: bySheet[pr.drawer_bottom_sheet_id] || null
      };
      var remapped = 0, thicknessChanged = 0;
      (s.parts_flat || []).forEach(function (p) {
        var role = roleOfKey(p.key);
        var t = role && target[role];
        if (!t) return;
        if (p.sheet_id !== t.sheet_id) { p.sheet_id = t.sheet_id; remapped++; }
        if (p.thickness_mm !== t.thickness_mm) { p.thickness_mm = t.thickness_mm; thicknessChanged++; }
      });
      if (remapped) {
        warnings.push(remapped + ' ردیف قطعه طبق تنظیمات پروژه به ورق بدنه/درب/پشت‌بند نگاشت شد');
      }
      if (thicknessChanged) {
        warnings.push(thicknessChanged + ' ردیف ضخامت تازه گرفت — ابعاد پارامتریک وابسته به ضخامت ' +
          'در اسکن بعدی داخل اسکچاپ بازمحاسبه می‌شود');
      }
      // نوار لبه در محاسبات: ضخامت نوار از اندازهٔ برش کم می‌شود تا اندازهٔ نهایی (قطعه+نوار)
      // درست دربیاید. قرارداد جهت: front/back در راستای طول (نوارشان به عرض اضافه می‌کند →
      // از cut_width کم می‌شود)؛ top/bottom در راستای عرض (→ از cut_length کم می‌شود).
      // فقط برای نواری که subtract روشن است. درب طبق خواستهٔ کاربر کسر نمی‌شود.
      var eb = pr.edge_band || {};
      var bandOf = function (role) { return role === 'door' ? (eb.door || {}) : (eb.body || {}); };
      var subtracted = 0;
      (s.parts_flat || []).forEach(function (p) {
        var role = roleOfKey(p.key);
        var spec = bandOf(role);
        if (!spec || !spec.subtract || !spec.thickness_mm) return; // فقط بدنه (subtract) کسر می‌شود
        var e = p.edge || {};
        var dLen = ((e.top || 0) + (e.bottom || 0)) * spec.thickness_mm;   // نوار عرض‌راستا → طول
        var dWid = ((e.front || 0) + (e.back || 0)) * spec.thickness_mm;   // نوار طول‌راستا → عرض
        if (dLen && p.cut_length_mm - dLen > 0) { p.cut_length_mm -= dLen; subtracted++; }
        if (dWid && p.cut_width_mm - dWid > 0) { p.cut_width_mm -= dWid; }
      });
      if (subtracted) {
        warnings.push(subtracted + ' قطعهٔ نواردار: ضخامت نوار از اندازهٔ برش کم شد (اندازهٔ نهایی درست)');
      }

      // فارسی‌بر (کج‌بری ۴۵°) روی قطعه: هر ضلع مثل groove — بدون داده در قطعاتی که ندارند،
      // با {} پیش‌فرض تا موتورهای مصرف‌کننده بی‌نیاز از چک null باشند.
      (s.parts_flat || []).forEach(function (p) {
        if (p.miter == null) p.miter = {};
        if (p.bevel == null) p.bevel = {};
      });

      // متادیتای ریل/نوار/علائم برای گزارش و علامت‌گذاری (موتورهای مصرف‌کننده مستقل می‌مانند)
      var mk = Object.assign({}, DEFAULT_MARKS, pr.marks || {});
      var marksOut = {};
      MARK_KEYS.forEach(function (mkey) {
        var m = mk[mkey] || DEFAULT_MARKS[mkey];
        marksOut[mkey] = { code: (m.code || DEFAULT_MARKS[mkey].code), label_fa: MARK_LABELS_FA[mkey] };
      });
      s.project = {
        slide_type: pr.slide_type || null,
        slide_type_fa: SLIDE_TYPES[pr.slide_type] || null,
        edge_band: {
          body: {
            thickness_mm: (eb.body && eb.body.thickness_mm) || null,
            note: (eb.body && eb.body.note) || '',
            subtract: !!(eb.body && eb.body.subtract)
          },
          door: {
            thickness_mm: (eb.door && eb.door.thickness_mm) || null,
            note: (eb.door && eb.door.note) || '',
            subtract: false
          }
        },
        marks: marksOut
      };
    }
    return { snapshot: s, warnings: warnings };
  }

  return { VERSION: VERSION, defaults: defaults, validate: validate,
           applyToSnapshot: applyToSnapshot, displayUnit: displayUnit,
           toUnit: toUnit, fromUnit: fromUnit,
           SLIDE_TYPES: SLIDE_TYPES, EDGE_BAND_THICKNESS: EDGE_BAND_THICKNESS, ROLE_KEYS: ROLE_KEYS,
           MARK_KEYS: MARK_KEYS, MARK_LABELS_FA: MARK_LABELS_FA, DEFAULT_MARKS: DEFAULT_MARKS };
}));
