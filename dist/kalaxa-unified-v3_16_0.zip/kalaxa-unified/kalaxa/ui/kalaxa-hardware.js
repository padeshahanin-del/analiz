/**
 * kalaxa-hardware.js — v1.0.0
 * موتور یراق: BOM قطعی از snapshot — بدون تغییر schema (استخراج از parts_flat + params).
 * JS خالص، UMD، بدون وابستگی.
 *
 * قواعد قطعی v1 (قابل override با options.rules):
 *   لولا:      ارتفاع درب <900→۲، <1600→۳، <2000→۴، وگرنه ۵ (به‌ازای هر لنگه)
 *   ریل کشو:   هر نمای کشو یک جفت؛ طول ریل = بزرگ‌ترین سایز استاندارد ≤ (عمق کابینت−50)
 *   دستگیره:   هر درب و هر کشو ۱
 *   پایه:      کابینت زمینی/قدی: عرض ≤900→۴، وگرنه ۶
 *   پین طبقه:  هر طبقه ۴
 *   مینی‌فیکس: هر قطعه افقی بدنه (کف/سقف/قید) ۴ عدد + دوبل به همان تعداد
 *
 * ادغام یراق صریح سند (v1.1 — D-HW-1):
 *   options.explicit = [{unit_id, name, kind, qty, sku}]
 *   سیاست: «صریح بر قاعده غالب است، به تفکیک (کابینت، نوع)» —
 *   اگر یونیتی یراق صریح از نوع K داشته باشد، سهم قاعده‌محور همان نوع برای همان
 *   کابینت حذف و ردیف‌های صریح جایگزین می‌شود؛ بقیه کابینت‌ها و نوع‌ها با قاعده
 *   پر می‌شوند. نگاشت نوع: hinge→لولا، slide→ریل، handle→دستگیره، leg→پایه،
 *   connector→مینی‌فیکس+دوبل؛ نوع ناشناخته فقط ردیف مستقل می‌شود.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.KalaxaHardware = factory();
  }
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var VERSION = '1.2.0';
  var SLIDE_SIZES = [250, 300, 350, 400, 450, 500, 550, 600];

  var DEFAULT_RULES = {
    hinge_breaks: [[900, 2], [1600, 3], [2000, 4], [Infinity, 5]],
    legs_narrow: 4, legs_wide: 6, legs_width_break_mm: 900,
    shelf_pins_per_shelf: 4,
    minifix_per_horizontal: 4,
    door_keys: ['door'],
    drawer_front_keys: ['drawer_front'],
    shelf_keys: ['shelf'],
    horizontal_keys: ['bottom', 'top_bottom', 'rail_top', 'rail_bottom']
  };

  function fa(n) {
    return String(n).replace(/[0-9]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[+d]; });
  }

  function hingesForDoorHeight(h, breaks) {
    for (var i = 0; i < breaks.length; i++) {
      if (h < breaks[i][0]) return breaks[i][1];
    }
    return breaks[breaks.length - 1][1];
  }

  // بزرگ‌ترین سایز استاندارد ≤ target؛ اگر عمق آن‌قدر کم است که هیچ‌کدام جا نشود،
  // به‌جای بازگشت خاموش به کوچک‌ترین سایز (که خلاف قرارداد مستندشده و گمراه‌کننده
  // بود)، null برمی‌گرداند تا caller آگاهانه تصمیم بگیرد و هشدار بدهد.
  function slideSizeForDepth(depthMm) {
    var target = depthMm - 50;
    var best = null;
    SLIDE_SIZES.forEach(function (s) { if (s <= target) best = s; });
    return best;
  }

  /**
   * @param {object} snapshot
   * @param {object} [options] - { rules: {...} }
   * @returns {items: [{item_id, name_fa, qty, unit, detail_fa}], by_cabinet: {...}}
   */
  function bom(snapshot, options) {
    options = options || {};
    var R = Object.assign({}, DEFAULT_RULES, options.rules || {});

    var cabMap = {};
    (snapshot.cabinets || []).forEach(function (c) { cabMap[c.kalaxa_id] = c; });

    var byCabinet = {};
    var shallowWarnings = {}; // "کابینت|عمق" → {cabinet, depth_mm} — عمق کمتر از حداقل ریل استاندارد
    function cab(id) {
      if (!byCabinet[id]) {
        byCabinet[id] = { hinge: 0, slide_pairs: 0, handle: 0, leg: 0, shelf_pin: 0, minifix: 0,
                          _slides: {}, _dowel: 0 };
      }
      return byCabinet[id];
    }

    (snapshot.parts_flat || []).forEach(function (p) {
      var c = cabMap[p.cabinet_id] || {};
      var params = c.params || {};
      var bc = cab(p.cabinet_id);

      if (R.door_keys.indexOf(p.key) !== -1) {
        var perDoor = hingesForDoorHeight(p.cut_length_mm, R.hinge_breaks);
        bc.hinge += perDoor * p.count;
        bc.handle += p.count;
      }

      if (R.drawer_front_keys.indexOf(p.key) !== -1) {
        var depthMm = (params.cabinet_depth || 55) * 10;
        var size = slideSizeForDepth(depthMm);
        if (size === null) {
          size = SLIDE_SIZES[0]; // بهترین تخمین ممکن، اما با هشدار صریح — نه سکوت
          shallowWarnings[(c.label_fa || p.cabinet_id) + '|' + depthMm] = {
            cabinet: c.label_fa || p.cabinet_id, depth_mm: depthMm
          };
        }
        bc._slides[size] = (bc._slides[size] || 0) + p.count;
        bc.slide_pairs += p.count;
        bc.handle += p.count;
      }

      if (R.shelf_keys.indexOf(p.key) !== -1) {
        bc.shelf_pin += R.shelf_pins_per_shelf * p.count;
      }

      if (R.horizontal_keys.indexOf(p.key) !== -1) {
        bc.minifix += R.minifix_per_horizontal * p.count;
        bc._dowel += R.minifix_per_horizontal * p.count;
      }
    });

    // پایه: به‌ازای هر کابینت روی زمین
    (snapshot.cabinets || []).forEach(function (c) {
      var catOnFloor = (c.category === 'base' || c.category === 'tall');
      if (!catOnFloor) return;
      var wMm = (c.params && c.params.cabinet_width || 0) * 10;
      cab(c.kalaxa_id).leg += wMm > R.legs_width_break_mm ? R.legs_wide : R.legs_narrow;
    });

    // --- ادغام یراق صریح (D-HW-1): صریح بر قاعده غالب، به تفکیک (کابینت، نوع) ---
    var KIND_FIELDS = { hinge: ['hinge'], handle: ['handle'], leg: ['leg'],
                        connector: ['minifix', '_dowel'] };
    var explicitRows = [];
    var overridden = {}; // "cabId|kind" → true (برای گزارش)
    (options.explicit || []).forEach(function (h) {
      if (!h || typeof h !== 'object') return;
      var qty = h.qty;
      if (typeof qty !== 'number' || !isFinite(qty) || qty <= 0 || qty !== Math.floor(qty)) return;
      explicitRows.push(h);
      var bc = byCabinet[h.unit_id];
      if (!bc) return; // یونیت بدون قطعه/کابینت — فقط ردیف مستقل
      var key = h.unit_id + '|' + h.kind;
      if (overridden[key]) return;
      overridden[key] = true;
      if (h.kind === 'slide') {
        bc._slides = {};
        bc.slide_pairs = 0;
      } else {
        (KIND_FIELDS[h.kind] || []).forEach(function (f) { bc[f] = 0; });
      }
    });

    // --- جمع‌بندی از per-cabinet ---
    var totals = { hinge: 0, handle: 0, leg: 0, shelf_pin: 0, minifix: 0, dowel: 0 };
    var slides = {};
    Object.keys(byCabinet).forEach(function (id) {
      var bc = byCabinet[id];
      totals.hinge += bc.hinge; totals.handle += bc.handle; totals.leg += bc.leg;
      totals.shelf_pin += bc.shelf_pin; totals.minifix += bc.minifix; totals.dowel += bc._dowel;
      Object.keys(bc._slides).forEach(function (sz) {
        slides[sz] = (slides[sz] || 0) + bc._slides[sz];
      });
      delete bc._slides; delete bc._dowel; // قرارداد خروجی by_cabinet مثل v1.0
    });

    var items = [];
    function push(id, name, qty, unit, detail) {
      if (qty > 0) items.push({ item_id: id, name_fa: name, qty: qty, unit: unit || 'عدد', detail_fa: detail || '' });
    }
    push('hinge', 'لولا آرام‌بند', totals.hinge, 'عدد', 'بر اساس ارتفاع هر لنگه');
    // نوع ریل از تنظیمات پروژه (اگر باشد) — فقط برچسب گزارش؛ item_id قرارداد قیمت ثابت می‌ماند
    var slideTypeFa = (snapshot.project && snapshot.project.slide_type_fa) || '';
    Object.keys(slides).sort(function (a, b) { return a - b; }).forEach(function (s) {
      push('slide_' + s, 'ریل کشو ' + fa(s) + ' میلی‌متر', slides[s], 'جفت',
           slideTypeFa ? 'نوع: ' + slideTypeFa : '');
    });
    push('handle', 'دستگیره', totals.handle, 'عدد', 'درب + کشو');
    push('leg', 'پایه تنظیمی', totals.leg, 'عدد', 'زمینی و قدی');
    push('shelf_pin', 'پین طبقه', totals.shelf_pin, 'عدد', '');
    push('minifix', 'مینی‌فیکس', totals.minifix, 'عدد', 'اتصالات افقی بدنه');
    push('dowel', 'دوبل چوبی', totals.dowel, 'عدد', '');

    // ردیف‌های صریح: گروه‌بندی بر اساس (نوع، نام، sku) — همیشه با نشان «صریح از سند»
    var expGroups = {};
    explicitRows.forEach(function (h) {
      var gk = [h.kind, h.name || '', h.sku || ''].join('|');
      if (!expGroups[gk]) expGroups[gk] = { kind: h.kind, name: h.name, sku: h.sku, qty: 0 };
      expGroups[gk].qty += h.qty;
    });
    Object.keys(expGroups).sort().forEach(function (gk) {
      var g = expGroups[gk];
      push('explicit_' + (g.sku || g.kind),
           g.name || g.kind, g.qty, 'عدد',
           'صریح از سند' + (g.sku ? ' — ' + g.sku : ''));
    });

    var warnings = Object.keys(shallowWarnings).map(function (k) {
      var w = shallowWarnings[k];
      return 'کابینت «' + w.cabinet + '» عمق ' + w.depth_mm + 'mm دارد — حتی کوچک‌ترین ریل ' +
        'استاندارد (' + SLIDE_SIZES[0] + 'mm) هم ممکن است جا نشود؛ اندازه دستی بررسی شود';
    });

    return { version: VERSION, items: items, by_cabinet: byCabinet, rules_used: R,
             explicit_count: explicitRows.length, warnings: warnings };
  }

  /** برآورد قیمت یراق: priceTable.hardware = { item_id: unit_price } (ریل: slide_450 و…) */
  function price(bomResult, priceTable) {
    var hw = (priceTable || {}).hardware || {};
    var lines = bomResult.items.map(function (it) {
      var unit = hw[it.item_id] || 0;
      return {
        kind: 'hardware', item_id: it.item_id,
        qty: it.qty, unit_price: unit, cost: unit * it.qty,
        label_fa: it.name_fa + ' × ' + it.qty
      };
    });
    return {
      lines: lines,
      total: lines.reduce(function (s, l) { return s + l.cost; }, 0)
    };
  }

  return { VERSION: VERSION, bom: bom, price: price, DEFAULT_RULES: DEFAULT_RULES };
}));
